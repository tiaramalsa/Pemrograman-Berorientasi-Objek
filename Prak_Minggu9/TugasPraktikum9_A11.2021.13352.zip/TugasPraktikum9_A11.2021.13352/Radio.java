public interface Radio{
    public void setGelombang(String gel);
} 