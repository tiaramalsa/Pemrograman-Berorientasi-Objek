abstract class Telepon{
    protected long nomer;
    public void telpon(){
        System.out.println("Sedang Menelepon");
    }
} 
